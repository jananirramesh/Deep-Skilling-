package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrmMappingApplication {
    public static void main(String[] args) {
        SpringApplication.run(OrmMappingApplication.class, args);
    }
}
