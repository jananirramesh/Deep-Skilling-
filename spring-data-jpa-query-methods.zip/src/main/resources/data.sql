INSERT INTO USER (name, email, age) VALUES ('Alice', 'alice@example.com', 25);
INSERT INTO USER (name, email, age) VALUES ('Bob', 'bob@example.net', 30);
INSERT INTO USER (name, email, age) VALUES ('Charlie', 'charlie@sample.org', 35);
INSERT INTO USER (name, email, age) VALUES ('Alice', 'alice2@sample.com', 28);
