INSERT INTO USER (name, email) VALUES ('Alice', 'alice@example.com');
INSERT INTO USER (name, email) VALUES ('Bob', 'bob@example.com');
