package com.example;

public class App {
    public static void main(String[] args) {
        SampleConfig config = new SampleConfig();
        config.showMessage();
    }
}