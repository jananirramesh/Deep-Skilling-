package com.example;

public class SampleConfig {
    public void showMessage() {
        System.out.println("Maven project configured successfully!");
    }
}