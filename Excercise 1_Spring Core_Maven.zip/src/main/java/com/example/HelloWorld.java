package com.example;

public class HelloWorld {
    public void sayHello() {
        System.out.println("Hello, Spring Core!");
    }
}