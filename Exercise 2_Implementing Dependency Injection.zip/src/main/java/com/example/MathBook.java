package com.example;

public class MathBook {
    public void display() {
        System.out.println("Studying Math...");
    }
}