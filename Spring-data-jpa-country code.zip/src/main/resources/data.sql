INSERT INTO COUNTRY (code, name) VALUES ('US', 'United States');
INSERT INTO COUNTRY (code, name) VALUES ('IN', 'India');
INSERT INTO COUNTRY (code, name) VALUES ('FR', 'France');
